document.addEventListener('DOMContentLoaded', function() {
    
    const isMobile = window.innerWidth <= 768;

    // --- API Endpoints ---
    const NOTIFICATIONS_API = 'https://jy-api.111312.xyz/notifications';
    const MONITORING_PROXY_API = 'https://up-api.111312.xyz/';
    const WEATHER_API = 'https://tq-api.111312.xyz';
    const NAS_WORKER_URL = 'https://nas-hook.111312.xyz/';

    // --- 全局变量 ---
    let monitorDataCache = [];
    let notificationsLoaded = false;
    let weatherLoaded = false;
    let monitoringLoaded = false;
    let nasCpuHistoryChart, nasNetworkHistoryChart, nasTempHistoryChart;

    // --- 1. 基础功能 ---
    function updateTime() {
        const now = new Date();
        const timeEl = document.getElementById('current-time');
        const dateEl = document.getElementById('current-date');
        if (timeEl) timeEl.textContent = now.toLocaleTimeString('zh-CN', { hour12: false });
        if (dateEl) dateEl.textContent = `${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日 ${['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'][now.getDay()]}`;
    }
    function countSites() {
        const sites = document.querySelectorAll('.nav-link');
        const siteCountEl = document.getElementById('site-count');
        if (siteCountEl) siteCountEl.textContent = sites.length;
    }

    // --- 2. 选项卡切换逻辑 ---
    function handleTabs() {
        const tabButtons = document.querySelectorAll('.tab-button');
        const tabContents = document.querySelectorAll('.tab-content');
        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                button.classList.add('active');
                const tabId = button.getAttribute('data-tab');
                const activeTab = document.getElementById(tabId);
                if (activeTab) activeTab.classList.add('active');
                if (tabId === 'tab-monitoring' && !monitoringLoaded) { initMonitoring(); monitoringLoaded = true; }
                if (tabId === 'tab-notifications' && !notificationsLoaded) { fetchNotifications(); notificationsLoaded = true; }
                if (tabId === 'tab-weather' && !weatherLoaded) { fetchWeatherData(); weatherLoaded = true; }
            });
        });
    }

    // --- 3. 我的通知功能 ---
    function showNotificationStatus(message, type = 'info') {
        const statusEl = document.getElementById('notifications-status-message');
        if (statusEl) {
            statusEl.innerHTML = `<div class="status-msg ${type}">${message}</div>`;
            if (type === 'success') { setTimeout(() => { statusEl.innerHTML = ''; }, 5000); }
        }
    }
    async function fetchNotifications() {
        const listEl = document.getElementById('notifications-list');
        if (!listEl) return;
        listEl.innerHTML = `<div class="loading-state"><div class="loading-spinner"></div><div>正在刷新...</div></div>`;
        try {
            const response = await fetch(NOTIFICATIONS_API);
            if (!response.ok) throw new Error(`HTTP错误! 状态码: ${response.status}`);
            const data = await response.json();
            if (data.success === false) throw new Error(`API返回错误: ${data.error || '未知错误'}`);
            if (data.notifications && data.notifications.length > 0) {
                listEl.innerHTML = '';
                data.notifications.forEach(item => {
                    const div = document.createElement('div');
                    div.className = 'notification-item';
                    const date = new Date(item.timestamp);
                    div.innerHTML = `<span class="notification-content">${item.content}</span><span class="notification-timestamp">${date.toLocaleString('zh-CN', { year: '2-digit', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>`;
                    listEl.appendChild(div);
                });
                showNotificationStatus(`成功加载 ${data.notifications.length} 条通知`, 'success');
            } else {
                listEl.innerHTML = `<div class="empty-state"><p>暂无通知或短信</p></div>`;
            }
        } catch (error) {
            console.error('获取通知失败:', error);
            listEl.innerHTML = `<div class="error-state"><p>加载失败: ${error.message}</p></div>`;
            showNotificationStatus(`加载失败: ${error.message}`, 'error');
        }
    }

    // --- 4. 服务监控功能 ---
    const STATUS_MAP = { 0: { text: '暂停中', class: 'status-warning', icon: 'fa-pause-circle' }, 1: { text: '未检查', class: 'status-warning', icon: 'fa-question-circle' }, 2: { text: '运行中', class: 'status-up', icon: 'fa-check-circle' }, 8: { text: '疑似故障', class: 'status-warning', icon: 'fa-exclamation-circle' }, 9: { text: '服务中断', class: 'status-down', icon: 'fa-times-circle' } };
    function showMonitoringError(message) {
        const container = document.getElementById('tab-monitoring');
        if (container) container.innerHTML = `<div class="error-state"><h2>加载数据失败</h2><p>${message}</p></div>`;
    }
    async function initMonitoring() {
        const container = document.getElementById('tab-monitoring');
        if (container) { container.innerHTML = `<div class="loading-state"><div class="loading-spinner"></div><p>正在加载服务监控数据...</p></div>`; }
        try {
            const response = await fetch(MONITORING_PROXY_API, { method: 'POST', cache: 'no-cache' });
            if (!response.ok) throw new Error(`API 请求失败: ${response.status}`);
            const data = await response.json();
            if (data.stat === 'fail') throw new Error(`API 返回错误: ${(data.error || {}).message || '未知'}`);
            renderCombinedMonitoringPage(data);
        } catch (error) {
            console.error('获取监控数据失败:', error);
            showMonitoringError(error.message);
        }
    }
    function renderCombinedMonitoringPage(data) {
        const container = document.getElementById('tab-monitoring');
        if (!container) return;
        container.innerHTML = '';
        const hasNasHistory = data.nas_history && (data.nas_history.cpu?.length > 0 || data.nas_history.network?.total?.length > 0 || data.nas_history.temp?.length > 0);
        const hasMonitors = data.monitors && data.monitors.length > 0;
        if (!hasNasHistory && !hasMonitors) { showMonitoringError("未能加载任何监控数据。"); return; }
        if (hasNasHistory) {
            const nasSection = document.createElement('div');
            nasSection.className = 'nas-section';
            nasSection.innerHTML = `<h2 class="section-title"><i class="fas fa-server"></i><span>NAS 历史趋势 (7天)</span></h2><div class="charts-grid"><div class="chart-container"><div class="chart-header"><h3 class="chart-title">CPU 使用率</h3></div><div class="nas-chart-wrapper"><canvas id="nasCpuHistoryChart"></canvas></div></div><div class="chart-container"><div class="chart-header"><h3 class="chart-title">网络总流量</h3></div><div class="nas-chart-wrapper"><canvas id="nasNetworkHistoryChart"></canvas></div></div><div class="chart-container" id="nas-temp-history-chart-container" style="display: none;"><div class="chart-header"><h3 class="chart-title">温度变化</h3></div><div class="nas-chart-wrapper"><canvas id="nasTempHistoryChart"></canvas></div></div></div>`;
            container.appendChild(nasSection);
            renderNasHistoryCharts(data.nas_history);
        }
        if (hasMonitors) {
            const monitors = data.monitors;
            monitorDataCache = monitors;
            let totalUptime = 0;
            monitors.forEach(m => {
                let uptimeRatio = parseFloat(m.custom_uptime_ratios?.split('-')[0]);
                if ((isNaN(uptimeRatio) || uptimeRatio === 0) && m.status === 2) { uptimeRatio = 100.0; }
                else if (isNaN(uptimeRatio)) { uptimeRatio = parseFloat(m.all_time_uptime_ratio) || 0; }
                totalUptime += uptimeRatio;
            });
            const servicesHTML = monitors.map(monitor => {
                const status = STATUS_MAP[monitor.status] || { text: '未知', class: 'status-warning', icon: 'fa-question-circle' };
                return `<div class="service-card" id="monitor-card-${monitor.id}"> <div class="service-card-header" onclick="toggleDetailChart(${monitor.id})"> <div class="service-header"> <div class="service-name">${monitor.friendly_name} <i class="fas fa-chevron-down"></i></div> <div class="service-status ${status.class}"><i class="fas ${status.icon}"></i> ${status.text}</div> </div> </div> <div class="service-details"> <div class="service-details-content"> <div class="detail-chart-container"><canvas id="detail-chart-${monitor.id}"></canvas></div> </div> </div> </div>`;
            }).join('');
            const uptimeContainer = document.createElement('div');
            uptimeContainer.id = 'uptime-robot-container';
            uptimeContainer.innerHTML = `<h2 class="section-title"><i class="fas fa-network-wired"></i><span>网站服务监控 (UptimeRobot)</span></h2><div class="charts-grid"><div class="summary-card uptime"><div class="card-icon"><i class="fas fa-chart-line"></i></div><div class="card-title">平均正常率 (7天)</div><div class="card-value">${monitors.length > 0 ? (totalUptime / monitors.length).toFixed(2) : '0'}%</div></div><div class="chart-container"><div class="chart-header"><h3 class="chart-title">平均响应时间 (24小时)</h3></div><div class="chart-wrapper"><canvas id="responseTimeChart"></canvas></div></div></div><div class="services-grid" style="margin-top: 30px;"><div id="services-list">${servicesHTML}</div></div>`;
            container.appendChild(uptimeContainer);
            renderOverviewCharts(monitors);
        }
    }
    function renderNasHistoryCharts(history) {
        if (nasCpuHistoryChart) nasCpuHistoryChart.destroy();
        if (nasNetworkHistoryChart) nasNetworkHistoryChart.destroy();
        if (nasTempHistoryChart) nasTempHistoryChart.destroy();
        const cpuCtx = document.getElementById('nasCpuHistoryChart')?.getContext('2d');
        if (cpuCtx && history.cpu && history.cpu.length > 0) {
            nasCpuHistoryChart = new Chart(cpuCtx, { type: 'line', data: { datasets: [{ label: 'CPU Usage (%)', data: history.cpu.map(d => ({x: d.timestamp * 1000, y: d.usage})), borderColor: 'rgba(30, 136, 229, 0.7)', backgroundColor: 'rgba(30, 136, 229, 0.1)', borderWidth: 1.5, pointRadius: 0, tension: 0.4, fill: true }] }, options: { responsive: true, maintainAspectRatio: false, scales: { x: { type: 'time', time: { unit: 'day' }, ticks: { font: { size: 10 } } }, y: { beginAtZero: true, max: 100, ticks: { font: { size: 10 } } } }, plugins: { legend: { display: false }, tooltip: { enabled: !isMobile, mode: 'x', intersect: false } } } });
        }
        const netCtx = document.getElementById('nasNetworkHistoryChart')?.getContext('2d');
        if (netCtx && history.network) {
            const datasets = [];
            if (history.network.total && history.network.total.length > 0) {
                datasets.push({ label: '总接收 (GB)', data: history.network.total.map(d => ({ x: d.timestamp * 1000, y: d.total_recv / 1024**3 })), borderColor: 'rgba(76, 175, 80, 0.7)', fill: false, borderWidth: 1.5, pointRadius: 0, tension: 0.4 });
                datasets.push({ label: '总发送 (GB)', data: history.network.total.map(d => ({ x: d.timestamp * 1000, y: d.total_sent / 1024**3 })), borderColor: 'rgba(255, 152, 0, 0.7)', fill: false, borderWidth: 1.5, pointRadius: 0, tension: 0.4 });
            }
            if (history.network.docker && history.network.docker.length > 0) {
                 datasets.push({ label: 'Docker 接收 (GB)', data: history.network.docker.map(d => ({ x: d.timestamp * 1000, y: d.total_recv / 1024**3 })), borderColor: 'rgba(156, 39, 176, 0.7)', fill: false, borderWidth: 1.5, pointRadius: 0, tension: 0.4, borderDash: [5, 5] });
                 datasets.push({ label: 'Docker 发送 (GB)', data: history.network.docker.map(d => ({ x: d.timestamp * 1000, y: d.total_sent / 1024**3 })), borderColor: 'rgba(8, 14, 153, 0.7)', fill: false, borderWidth: 1.5, pointRadius: 0, tension: 0.4, borderDash: [5, 5] });
            }
            if (datasets.length > 0) {
                nasNetworkHistoryChart = new Chart(netCtx, { type: 'line', data: { datasets: datasets }, options: { responsive: true, maintainAspectRatio: false, scales: { x: { type: 'time', time: { unit: 'day' }, ticks: { font: { size: 10 } } }, y: { beginAtZero: true, title: { display: !isMobile, text: 'GB' }, ticks: { font: { size: 10 } } } }, plugins: { legend: { display: !isMobile, position: 'bottom', labels: { font: { size: 10 } } }, tooltip: { enabled: !isMobile, mode: 'x', intersect: false } } } });
            }
        }
        if (history.temp && history.temp.length > 0) {
            const tempContainer = document.getElementById('nas-temp-history-chart-container');
            if (tempContainer) tempContainer.style.display = 'block';
            const tempCtx = document.getElementById('nasTempHistoryChart')?.getContext('2d');
            if(tempCtx) {
                nasTempHistoryChart = new Chart(tempCtx, { type: 'line', data: { datasets: [{ label: '温度 (°C)', data: history.temp.map(d => ({ x: d.timestamp * 1000, y: d.temperature })), borderColor: 'rgba(244, 67, 54, 0.7)', backgroundColor: 'rgba(244, 67, 54, 0.1)', borderWidth: 1.5, pointRadius: 0, tension: 0.4, fill: true }] }, options: { responsive: true, maintainAspectRatio: false, scales: { x: { type: 'time', time: { unit: 'day' }, ticks: { font: { size: 10 } } }, y: { beginAtZero: false, title: { display: !isMobile, text: '°C' }, ticks: { font: { size: 10 } } } }, plugins: { legend: { display: false }, tooltip: { enabled: !isMobile, mode: 'x', intersect: false } } } });
            }
        }
    }
    window.toggleDetailChart = function(monitorId) {
        const card = document.getElementById(`monitor-card-${monitorId}`);
        if (!card) return;
        const isExpanded = card.classList.toggle('expanded');
        if (isExpanded) {
            const monitor = monitorDataCache.find(m => m.id === monitorId);
            if (monitor && monitor.response_times) createDetailChart(monitor);
        }
    };
    function createDetailChart(monitor) {
        const canvasId = `detail-chart-${monitor.id}`, ctx = document.getElementById(canvasId)?.getContext('2d');
        if (!ctx) return;
        if (Chart.getChart(ctx)) Chart.getChart(ctx).destroy();
        const chartData = monitor.response_times.map(rt => ({ x: rt.datetime * 1000, y: rt.value })).reverse();
        new Chart(ctx, { type: 'line', data: { datasets: [{ label: '响应时间 (ms)', data: chartData, borderColor: 'rgba(30, 136, 229, 0.5)', backgroundColor: 'rgba(30, 136, 229, 0.1)', borderWidth: 1, tension: 0.3, fill: true, pointRadius: 0 }] }, options: { responsive: true, maintainAspectRatio: false, scales: { x: { type: 'time', time: { unit: 'hour' }, ticks: { font: { size: 10 } } }, y: { beginAtZero: true, ticks: { font: { size: 10 } } } }, plugins: { legend: { display: false }, tooltip: { enabled: !isMobile, mode: 'x', intersect: false } } } });
    }
    function renderOverviewCharts(monitors) {
        const rtCtx = document.getElementById('responseTimeChart')?.getContext('2d');
        if (rtCtx) {
            if (Chart.getChart(rtCtx)) Chart.getChart(rtCtx).destroy();
            new Chart(rtCtx, { type: 'bar', data: { labels: monitors.map(m => m.friendly_name.substring(0, isMobile ? 5 : 12) + (m.friendly_name.length > (isMobile ? 5 : 12) ? '...' : '')), datasets: [{ label: '响应时间 (ms)', data: monitors.map(m => m.average_response_time || 0), backgroundColor: 'rgba(30, 136, 229, 0.7)' }] }, options: { responsive: true, maintainAspectRatio: false, scales: { x: { ticks: { font: { size: 10 } } }, y: { beginAtZero: true, ticks: { font: { size: 10 } } } }, plugins: { legend: { display: false }, tooltip: { enabled: !isMobile, mode: 'x', intersect: false } } } });
        }
    }
    
    // --- 5. 天气仪表盘功能 ---
    const sourceStyles = { 'HefengAPI': { label: 'API', tempColor: 'rgb(255, 99, 132)', humidColor: 'rgb(255, 159, 64)' }, 'ESP8266':   { label: '设备', tempColor: 'rgb(54, 162, 235)', humidColor: 'rgb(75, 192, 192)' }, 'default':   { label: '其他', tempColor: 'rgb(201, 203, 207)', humidColor: 'rgb(153, 102, 255)' } };
    async function fetchWeatherData() {
        const loadingMessage = document.getElementById('weather-loading-message');
        const cardsContainer = document.getElementById('latest-weather-cards');
        const chartsContainer = document.getElementById('weather-charts-container');
        try {
            const response = await fetch(WEATHER_API);
            if (!response.ok) throw new Error(`无法从 Worker 获取数据，状态码: ${response.status}`);
            const data = await response.json();
            if (loadingMessage) loadingMessage.style.display = 'none';
            if (cardsContainer) cardsContainer.style.display = 'flex';
            if (chartsContainer) chartsContainer.style.display = 'flex';
            displayLatestWeather(data.latest);
            displayTrendCharts(data.history);
        } catch (error) {
            console.error('加载天气数据时发生错误:', error);
            if (loadingMessage) loadingMessage.innerHTML = `<div class="error-state"><h2>加载天气数据失败</h2><p>${error.message}</p></div>`;
        }
    }
    function displayLatestWeather(latestData) {
        const container = document.getElementById('latest-weather-cards');
        if (!container) return;
        container.innerHTML = ''; 
        if (!latestData || latestData.length === 0) { container.innerHTML = "<p>暂无最新的天气数据。</p>"; return; }
        for (const cityData of latestData) {
            const card = document.createElement('div');
            card.className = 'weather-card';
            card.innerHTML = `<h2>${cityData.city_name}</h2> <p class="weather-text">${cityData.weather_text}</p> <p><strong>温度:</strong> ${cityData.temperature}°C (体感 ${cityData.feels_like}°C)</p> <p><strong>相对湿度:</strong> ${cityData.humidity}%</p> <p class="timestamp">更新于: ${new Date(cityData.observation_time).toLocaleString()}</p>`;
            container.appendChild(card);
        }
    }
    function displayTrendCharts(historyData) {
        const container = document.getElementById('weather-charts-container');
        if (!container) return;
        container.innerHTML = '';
        if (!historyData || historyData.length === 0) return;
        const cities = {};
        for (const record of historyData) { if (!cities[record.city_name]) cities[record.city_name] = []; cities[record.city_name].push(record); }
        for (const cityName in cities) {
            const chartContainer = document.createElement('div');
            chartContainer.className = 'weather-chart-container';
            const canvas = document.createElement('canvas');
            chartContainer.appendChild(canvas);
            container.appendChild(chartContainer);
            const datasets = [];
            const cityHistory = cities[cityName];
            const sources = {};
            for (const record of cityHistory) { if (!sources[record.source]) sources[record.source] = []; sources[record.source].push(record); }
            for (const sourceName in sources) {
                const style = sourceStyles[sourceName] || sourceStyles.default;
                const sourceData = sources[sourceName];
                datasets.push({ label: `温度 - ${style.label}`, data: sourceData.map(d => ({ x: new Date(d.observation_time), y: d.temperature })), borderColor: style.tempColor, backgroundColor: style.tempColor.replace('rgb', 'rgba').replace(')', ', 0.5)'), yAxisID: 'y', tension: 0.1, borderWidth: 1.5, pointRadius: 0 });
                datasets.push({ label: `湿度 - ${style.label}`, data: sourceData.map(d => ({ x: new Date(d.observation_time), y: d.humidity })), borderColor: style.humidColor, backgroundColor: style.humidColor.replace('rgb', 'rgba').replace(')', ', 0.5)'), yAxisID: 'y1', borderDash: [5, 5], tension: 0.1, borderWidth: 1.5, pointRadius: 0 });
            }
            new Chart(canvas, { type: 'line', data: { datasets: datasets }, options: { responsive: true, interaction: { mode: 'x', intersect: false, }, plugins: { title: { display: true, text: `${cityName} - 24小时趋势`, font: { size: isMobile ? 14 : 18 } }, legend: { display: !isMobile, position: 'bottom', labels: { font: { size: 10 } } } }, scales: { x: { type: 'time', time: { unit: 'hour', tooltipFormat: 'HH:mm', displayFormats: { hour: 'HH:mm' } }, title: { display: false }, ticks: { font: { size: 10 } } }, y: { type: 'linear', display: true, position: 'left', title: { display: !isMobile, text: '温度 (°C)' }, ticks: { font: { size: 10 } } }, y1: { type: 'linear', display: true, position: 'right', title: { display: !isMobile, text: '湿度 (%)' }, grid: { drawOnChartArea: false }, ticks: { font: { size: 10 } } } } } });
        }
    }

    // --- 6. NAS 实时动态监控模块 (顶部) ---
    function initNasModule() {
        const DEFAULT_NAS_URLS = [
            'https://nas-api.111312.xyz/metrics',
            'https://wkyapi.111312.xyz/metrics',
            'https://macapi.111312.xyz/metrics'
        ];

        let nasInstances = {};
        let nasUrlList = [];
        let updateInterval;
        let totalSpeeds = { up: 0, down: 0 };
        const originalTitle = document.title;

        function nas_formatBytes(bytes, decimals = 1) {
            if (bytes === undefined || bytes === null || bytes <= 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return `${parseFloat((bytes / Math.pow(k, i)).toFixed(decimals))} ${sizes[i]}`;
        }
        function nas_formatSpeed(bytesPerSecond, decimals = 2) {
             if (bytesPerSecond === undefined || bytesPerSecond === null || bytesPerSecond < 1) return `0 KB/s`;
            const k = 1024;
            const sizes = ['B/s', 'KB/s', 'MB/s', 'GB/s'];
            const i = Math.floor(Math.log(bytesPerSecond) / Math.log(k));
            return `${parseFloat((bytesPerSecond / Math.pow(k, i)).toFixed(decimals))} ${sizes[i]}`;
        }
        function nas_formatUptime(seconds) {
            if (!seconds || seconds <= 0) return '--';
            seconds = Math.floor(seconds);
            const d = Math.floor(seconds / 86400);
            const h = Math.floor(seconds % 86400 / 3600);
            const m = Math.floor(seconds % 3600 / 60);
            return `${d}天 ${h}小时 ${m}分钟`;
        }
        function parseNasRealtimeMetrics(text) {
            const metrics = { cpu: { total: 0, idle: 0 }, memory: { total: 0, available: 0 }, network: { received: 0, transmitted: 0 }, bootTime: 0, temp: null, filesystems: {} };
            const ignoredInterfaces = /^(lo|veth|docker0|tailscale0)/;
            let primaryInterface = null;
            const networkData = {};
            const targetMountpoint = '/etc/hostname';
            const lines = text.split('\n');
            for (const line of lines) {
                if (line.startsWith('#')) continue;
                const parts = line.split(' ');
                const value = parseFloat(parts[1]);
                if (line.startsWith('node_cpu_seconds_total')) {
                    const modeMatch = line.match(/mode="([^"]+)"/);
                    if (modeMatch) {
                        metrics.cpu.total += value;
                        if (modeMatch[1] === 'idle') metrics.cpu.idle += value;
                    }
                } else if (line.startsWith('node_memory_MemTotal_bytes')) metrics.memory.total = value;
                else if (line.startsWith('node_memory_MemAvailable_bytes')) metrics.memory.available = value;
                else if (line.startsWith('node_network_receive_bytes_total') || line.startsWith('node_network_transmit_bytes_total')) {
                    const isReceive = line.startsWith('node_network_receive_bytes_total');
                    const interfaceMatch = line.match(/device="([^"]+)"/);
                    if (interfaceMatch) {
                        const device = interfaceMatch[1];
                        if (!networkData[device]) networkData[device] = { received: 0, transmitted: 0 };
                        if (isReceive) networkData[device].received = value;
                        else networkData[device].transmitted = value;
                    }
                } else if (line.startsWith('node_boot_time_seconds')) metrics.bootTime = value;
                else if (line.startsWith('node_thermal_zone_temp') || line.startsWith('node_hwmon_temp_input')) {
                     if (metrics.temp === null) metrics.temp = value;
                }
                else if (line.startsWith('node_filesystem_size_bytes') || line.startsWith('node_filesystem_avail_bytes')) {
                    const mountpointMatch = line.match(/mountpoint="([^"]+)"/);
                    if (mountpointMatch && mountpointMatch[1] === targetMountpoint) {
                        const mountpoint = mountpointMatch[1];
                        if (!metrics.filesystems[mountpoint]) metrics.filesystems[mountpoint] = { size: 0, avail: 0 };
                        if (line.startsWith('node_filesystem_size_bytes')) metrics.filesystems[mountpoint].size = value;
                        if (line.startsWith('node_filesystem_avail_bytes')) metrics.filesystems[mountpoint].avail = value;
                    }
                }
            }
            for (const device in networkData) {
                if (!ignoredInterfaces.test(device)) {
                    primaryInterface = device;
                    break;
                }
            }
            if (!primaryInterface && networkData['eth0']) {
                primaryInterface = 'eth0';
            }
            if (primaryInterface && networkData[primaryInterface]) {
                metrics.network = networkData[primaryInterface];
            }
            return metrics;
        }
        function getUrlsFromStorage() {
            const storedUrls = localStorage.getItem('nasUrlList');
            if (storedUrls) {
                try {
                    const parsed = JSON.parse(storedUrls);
                    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_NAS_URLS;
                } catch (e) {
                    return DEFAULT_NAS_URLS;
                }
            } else {
                localStorage.setItem('nasUrlList', JSON.stringify(DEFAULT_NAS_URLS));
                return DEFAULT_NAS_URLS;
            }
        }
        function saveUrlsToStorage(urls) {
            localStorage.setItem('nasUrlList', JSON.stringify(urls));
        }
        function createNasCardHtml(url, index) {
            const urlHostname = new URL(url).hostname;
            return `<div class="nas-card-container" data-url="${url}"> <div style="font-weight: bold; color: var(--primary-dark); margin-bottom: 15px; text-align: center;">${urlHostname}</div> <div class="nas-card-grid"> <div class="nas-metric-card"><div class="nas-metric-icon"><i class="fas fa-microchip"></i></div><div class="nas-metric-details"><span class="nas-metric-label">CPU</span><div class="nas-metric-value" id="nas-cpu-usage-${index}">--%</div></div></div> <div class="nas-metric-card"><div class="nas-metric-icon"><i class="fas fa-memory"></i></div><div class="nas-metric-details"><span class="nas-metric-label">内存</span><div class="nas-metric-value" id="nas-mem-usage-${index}">--%</div><div class="nas-metric-subvalue" id="nas-mem-details-${index}">--/--GB</div></div></div> <div class="nas-metric-card" id="nas-temp-card-${index}" style="display: none;"><div class="nas-metric-icon"><i class="fas fa-thermometer-half"></i></div><div class="nas-metric-details"><span class="nas-metric-label">温度</span><div class="nas-metric-value" id="nas-temp-value-${index}">--°C</div></div></div> <div class="nas-metric-card"><div class="nas-metric-icon"><i class="fas fa-exchange-alt"></i></div><div class="nas-metric-details"><span class="nas-metric-label">上传/下载</span><div class="nas-metric-value small-font" id="nas-net-speed-${index}">-- / --</div></div></div> <div class="nas-metric-card"><div class="nas-metric-icon"><i class="fas fa-hdd"></i></div><div class="nas-metric-details"><span class="nas-metric-label">系统存储</span><div class="nas-metric-value" id="nas-disk-usage-${index}">--%</div><div class="nas-metric-subvalue" id="nas-disk-details-${index}">--/--GB</div></div></div> <div class="nas-metric-card"><div class="nas-metric-icon"><i class="fas fa-history"></i></div><div class="nas-metric-details"><span class="nas-metric-label">运行时间</span><div class="nas-metric-value small-font" id="nas-system-uptime-${index}">--</div><div class="nas-metric-subvalue" id="nas-boot-time-${index}">--</div></div></div> </div> <div id="nas-status-footer-${index}" class="nas-status-footer"><span id="nas-status-text-${index}">正在连接...</span><span id="nas-error-text-${index}" class="nas-error"></span></div> </div>`;
        }
        function renderNasContainers() {
            const container = document.getElementById('nas-grid-container');
            if (!container) return;
            container.innerHTML = nasUrlList.map(createNasCardHtml).join('');
        }
        function renderUrlListInModal() {
            const listContainer = document.getElementById('nas-url-list');
            if (!listContainer) return;
            listContainer.innerHTML = nasUrlList.map((url, index) => `<div class="nas-url-item"> <span>${url}</span> <button data-index="${index}" class="delete-nas-button">删除</button> </div>`).join('');
        }
        
        function updatePageTitle() {
            const upSpeed = nas_formatSpeed(totalSpeeds.up, 1);
            const downSpeed = nas_formatSpeed(totalSpeeds.down, 1);
            document.title = `↑${upSpeed} / ↓${downSpeed} | ${originalTitle}`;
        }

        async function updateSingleNasDisplay(url, index) {
            const errorText = document.getElementById(`nas-error-text-${index}`);
            try {
                const response = await fetch(NAS_WORKER_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url: url }) });
                if (!response.ok) throw new Error(`代理请求失败: ${response.status}`);
                const text = await response.text();
                if (text.includes('Error:')) throw new Error(text.replace('Error: ', ''));
                const now = Date.now();
                const instance = nasInstances[url] || {};
                const currentMetrics = parseNasRealtimeMetrics(text);
                
                const updateElement = (id, content) => {
                    const el = document.getElementById(id);
                    if (el) el.innerHTML = content;
                };

                if (instance.previousCpuData) {
                    const totalDiff = currentMetrics.cpu.total - instance.previousCpuData.total;
                    const idleDiff = currentMetrics.cpu.idle - instance.previousCpuData.idle;
                    updateElement(`nas-cpu-usage-${index}`, `${(totalDiff > 0 ? 100 * (1 - (idleDiff / totalDiff)) : 0).toFixed(1)}%`);
                }
                const memUsed = currentMetrics.memory.total - currentMetrics.memory.available;
                updateElement(`nas-mem-usage-${index}`, `${(100 * memUsed / currentMetrics.memory.total).toFixed(1)}%`);
                updateElement(`nas-mem-details-${index}`, `${nas_formatBytes(memUsed, 2)}/${nas_formatBytes(currentMetrics.memory.total, 2)}`);
                
                const tempCard = document.getElementById(`nas-temp-card-${index}`);
                if (currentMetrics.temp !== null) {
                    if(tempCard) tempCard.style.display = 'flex';
                    updateElement(`nas-temp-value-${index}`, `${currentMetrics.temp.toFixed(1)}°C`);
                }
                
                let upSpeed = 0, downSpeed = 0;
                if (instance.previousNetData && instance.lastFetchTime) {
                    const timeDelta = (now - instance.lastFetchTime) / 1000;
                    if(timeDelta > 0) {
                        downSpeed = (currentMetrics.network.received - instance.previousNetData.received) / timeDelta;
                        upSpeed = (currentMetrics.network.transmitted - instance.previousNetData.transmitted) / timeDelta;
                        updateElement(`nas-net-speed-${index}`, `${nas_formatSpeed(upSpeed)} / ${nas_formatSpeed(downSpeed)}`);
                    }
                }
                nasInstances[url] = { ...nasInstances[url], upSpeed: upSpeed, downSpeed: downSpeed };

                const diskData = currentMetrics.filesystems['/etc/hostname'];
                if (diskData && diskData.size > 0) {
                    const diskUsed = diskData.size - diskData.avail;
                    const diskPercent = (100 * diskUsed / diskData.size).toFixed(1);
                    updateElement(`nas-disk-usage-${index}`, `${diskPercent}%`);
                    updateElement(`nas-disk-details-${index}`, `(${nas_formatBytes(diskUsed)}/${nas_formatBytes(diskData.size)})`);
                }
                if (currentMetrics.bootTime > 0) {
                    nasInstances[url] = { ...nasInstances[url], bootTimestamp: currentMetrics.bootTime };
                    const bootDate = new Date(currentMetrics.bootTime * 1000);
                    updateElement(`nas-boot-time-${index}`, `开机于: ${bootDate.toLocaleDateString()}`);
                }
                nasInstances[url] = { ...nasInstances[url], previousCpuData: currentMetrics.cpu, previousNetData: currentMetrics.network, lastFetchTime: now };
                const statusText = document.getElementById(`nas-status-text-${index}`);
                if (statusText) statusText.textContent = `上次更新: ${new Date().toLocaleTimeString()}`;
                if (errorText) errorText.textContent = '';
            } catch (error) {
                console.error(`更新NAS[${url}]状态失败:`, error);
                if (errorText) errorText.textContent = `错误: ${error.message}`;
                nasInstances[url] = { ...nasInstances[url], upSpeed: 0, downSpeed: 0 };
            }
        }
        function updateAllUptimes() {
            nasUrlList.forEach((url, index) => {
                const instance = nasInstances[url];
                if (instance && instance.bootTimestamp > 0) {
                    const uptimeEl = document.getElementById(`nas-system-uptime-${index}`);
                    if (uptimeEl) uptimeEl.textContent = nas_formatUptime((Date.now() / 1000) - instance.bootTimestamp);
                }
            });
        }
        function startUpdatingAllNas() {
            if (updateInterval) clearInterval(updateInterval);
            const updateAll = async () => {
                const updatePromises = nasUrlList.map((url, index) => updateSingleNasDisplay(url, index));
                await Promise.all(updatePromises);
                
                totalSpeeds = { up: 0, down: 0 };
                for (const url in nasInstances) {
                    if (nasUrlList.includes(url)) {
                        totalSpeeds.up += nasInstances[url].upSpeed || 0;
                        totalSpeeds.down += nasInstances[url].downSpeed || 0;
                    }
                }
                updatePageTitle();
            };
            updateAll();
            updateInterval = setInterval(updateAll, 10000);
        }
        function setupSettingsModal() {
            const icon = document.getElementById('settings-icon');
            const overlay = document.getElementById('settings-modal-overlay');
            const closeButton = document.getElementById('settings-close-button');
            const addButton = document.getElementById('add-nas-button');
            const urlInput = document.getElementById('new-nas-url');
            const urlListContainer = document.getElementById('nas-url-list');
            if (!icon || !overlay || !closeButton || !addButton || !urlInput || !urlListContainer) return;
            const openModal = () => { renderUrlListInModal(); overlay.style.display = 'flex'; };
            const closeModal = () => { overlay.style.display = 'none'; };
            icon.addEventListener('click', openModal);
            closeButton.addEventListener('click', closeModal);
            overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });
            addButton.addEventListener('click', () => {
                const newUrl = urlInput.value.trim();
                if (newUrl && !nasUrlList.includes(newUrl)) {
                    nasUrlList.push(newUrl);
                    saveUrlsToStorage(nasUrlList);
                    renderUrlListInModal();
                    renderNasContainers();
                    startUpdatingAllNas();
                    urlInput.value = '';
                }
            });
            urlListContainer.addEventListener('click', (e) => {
                if (e.target.classList.contains('delete-nas-button')) {
                    const indexToRemove = parseInt(e.target.getAttribute('data-index'), 10);
                    const urlToRemove = nasUrlList[indexToRemove];
                    delete nasInstances[urlToRemove];
                    nasUrlList.splice(indexToRemove, 1);
                    saveUrlsToStorage(nasUrlList);
                    renderUrlListInModal();
                    renderNasContainers();
                    startUpdatingAllNas();
                }
            });
        }
        
        nasUrlList = getUrlsFromStorage();
        renderNasContainers();
        startUpdatingAllNas();
        setInterval(updateAllUptimes, 1000);
        setupSettingsModal();
    }

    // --- 主应用初始化 ---
    function initialize() {
        updateTime();
        setInterval(updateTime, 1000);
        countSites();
        handleTabs();
        initNasModule();
        const refreshBtn = document.getElementById('refresh-notifications-btn');
        if (refreshBtn) refreshBtn.addEventListener('click', fetchNotifications);
    }

    initialize();
});
